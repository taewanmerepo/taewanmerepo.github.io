
drop table USER_TYPES CASCADE CONSTRAINTS;
drop table TEAMS CASCADE CONSTRAINTS;
drop table JOB_TYPES CASCADE CONSTRAINTS;
drop table EMPLOYEES CASCADE CONSTRAINTS;
drop table EXPENSE_TYPES CASCADE CONSTRAINTS;
drop table EXPENSES CASCADE CONSTRAINTS;
drop table EXPENSE_REPORTS CASCADE CONSTRAINTS;
drop table EXPENSE_REPORT_ITEMS CASCADE CONSTRAINTS;
drop view EXPENSE_REPORT_ITEMS_V;


CREATE TABLE JOB_TYPES 
( 
job_id	       number(2)  NOT NULL,
job_name	   VARCHAR2(20) NOT NULL,
CONSTRAINT job_type_pk PRIMARY KEY ( job_id )
);

insert into JOB_TYPES values(1, '의사');
insert into JOB_TYPES values(2, '간호사');

CREATE TABLE TEAMS 
( 
team_id	       number(3)  NOT NULL,
team_name	   VARCHAR2(20) NOT NULL,
team_full_name VARCHAR2(100) NOT NULL,
CONSTRAINT teams_pk PRIMARY KEY ( team_id )
);

insert into TEAMS values(1, 'PDS', '소아과');
insert into TEAMS values(2, 'OB&GY', '산부인과');
insert into TEAMS values(3, 'GS', '간담췌외과');
insert into TEAMS values(4, 'NS', '신경외과');
insert into TEAMS values(5, 'EM', '응급의학과');

CREATE TABLE USER_TYPES 
( 
type_id	       number(3)  NOT NULL,
type_name	   VARCHAR2(20) NOT NULL,
job_id	       number(2)  NOT NULL,
CONSTRAINT USER_TYPES_pk PRIMARY KEY ( type_id ),
CONSTRAINT USER_TYPES_JOB_ID_FK FOREIGN KEY (job_id) references JOB_TYPES
);

insert into USER_TYPES values(1, '교수', 1);
insert into USER_TYPES values(2, '펠로우', 1);
insert into USER_TYPES values(3, '레시던트', 1);
insert into USER_TYPES values(4, '인턴', 1);
insert into USER_TYPES values(5, '본과실습생', 1);
insert into USER_TYPES values(6, '간호사', 2);
insert into USER_TYPES values(7, '주임간호사', 2);
insert into USER_TYPES values(8, '수간호사', 2);
insert into USER_TYPES values(9, '간호부장', 2);

CREATE TABLE EMPLOYEES 
(
employee_id    VARCHAR2(50) NOT NULL, 
email	       VARCHAR2(50) NOT NULL,
emp_name	   VARCHAR2(20) NOT NULL,
emp_pw		   VARCHAR2(200),
cell_phone	   VARCHAR2(13) NOT NULL,
job_id	       number(2)  NOT NULL,	   
type_id	       number(3) NOT NULL,
team_id	       number(3) NOT NULL,
gender         VARCHAR2(2) Not Null,
birth_day	   DATE,
emp_pic	       BLOB,
cre_date       DATE,
temp_pw        VARCHAR2(200),
CONSTRAINT employees_pk PRIMARY KEY (employee_id),
CONSTRAINT employees_job_id_fk FOREIGN KEY (job_id) references JOB_TYPES,
CONSTRAINT employees_type_id_fk FOREIGN KEY (type_id) references USER_TYPES,
CONSTRAINT employees_team_id_fk FOREIGN KEY (team_id) references TEAMS
);


CREATE TABLE EXPENSE_TYPES 
( 
type_id        number(3)  NOT NULL,
type_name	   VARCHAR2(50) NOT NULL,
CONSTRAINT EXPENSE_TYPES_pk PRIMARY KEY ( type_id )
);

insert into EXPENSE_TYPES values(1, '대중교통비');
insert into EXPENSE_TYPES values(2, '중식');
insert into EXPENSE_TYPES values(3, '석식');
insert into EXPENSE_TYPES values(4, '음료/다과');
insert into EXPENSE_TYPES values(5, '세마나');
insert into EXPENSE_TYPES values(6, '도서구입');
insert into EXPENSE_TYPES values(7, '소모품'); 


CREATE TABLE EXPENSES
( 
expense_id 		number(9) not null,
employee_id 	VARCHAR2(50) not null,
type_id 		number(3),
payment_amount 	number(8),
title           VARCHAR2(200),
description 	VARCHAR2(1024),
receipt_status	VARCHAR2(2), --missing/keeping
card_type		VARCHAR2(2), --추가 할것 (개인카드/법인카드)
receipt_pic	    BLOB,
use_date		DATE,
cre_date    	DATE,
CONSTRAINT expenses_pk PRIMARY KEY (expense_id),
CONSTRAINT expenses_employee_id_fk FOREIGN KEY (employee_id) references EMPLOYEES,
CONSTRAINT expenses_type_id_fk FOREIGN KEY (type_id) references EXPENSE_TYPES
);

CREATE TABLE EXPENSE_REPORTS
( 
expense_report_id number(9) not null,
employee_id     VARCHAR2(50) not null,
report_title	VARCHAR2(50) not null,
company_card_receipt_num number(3),
private_card_receiept_num number(3),
company_card_amount number(9),
private_card_amount number(9),
cre_date    	DATE,
CONSTRAINT expense_reports_pk PRIMARY KEY (expense_report_id),
CONSTRAINT expense_reports_employee_id_fk FOREIGN KEY (employee_id) references EMPLOYEES
);

CREATE TABLE EXPENSE_REPORT_ITEMS
( 
report_id 		number(9) not null,
expense_id 		number(9) not null,
CONSTRAINT expense_report_items_pk PRIMARY KEY (report_id, expense_id),
CONSTRAINT expense_report_items_report_id_fk FOREIGN KEY (report_id) references EXPENSE_REPORTS,
CONSTRAINT expense_report_items_expense_id_fk FOREIGN KEY (expense_id) references EXPENSES
);


-- 카드 여부 추가해야 함
CREATE OR REPLACE VIEW EXPENSE_REPORT_ITEMS_V AS 
select i.REPORT_ID, i.EXPENSE_ID, 
	e.EMPLOYEE_ID, e.TYPE_ID, e.PAYMENT_AMOUNT, 
	e.title, e.DESCRIPTION, e.USE_DATE, e.cre_date
from EXPENSE_REPORT_ITEMS i, EXPENSES e 
where i.EXPENSE_ID=e.EXPENSE_ID 


